import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { LeftSidebar } from '@/components/LeftSidebar';
import { BackButton } from '@/components/BackButton';
import { KindnessConnectModal } from '@/components/KindnessConnectModal';
import { TeacherAppreciationMetrics } from '@/components/TeacherAppreciationMetrics';

interface School {
  id: string;
  name: string;
  type: 'elementary' | 'middle' | 'high' | 'university' | 'preschool' | 'private';
  studentCount: number;
  teacherCount: number;
  totalKindnessActs: number;
  avgKindnessScore: number;
}


interface SchoolsDashboardProps {
  onNavigateToTab?: (tab: string) => void;
  activeBottomTab?: string;
}

export function SchoolsDashboard({ onNavigateToTab, activeBottomTab = 'schools' }: SchoolsDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'student' | 'teacher' | 'admin' | 'parent'>('overview');
  const [, navigate] = useLocation();
  const [isKindnessConnectOpen, setIsKindnessConnectOpen] = useState(false);

  // Fetch schools data
  const { data: schools = [] } = useQuery<School[]>({
    queryKey: ['/api/schools'],
  });


  // Sample data for demonstration - Dudley High School
  const sampleSchools: School[] = [
    {
      id: 'dudley-high-school',
      name: 'Dudley High School',
      type: 'high',
      studentCount: 1200,
      teacherCount: 85,
      totalKindnessActs: 3842,
      avgKindnessScore: 8.9
    }
  ];


  const getSchoolIcon = (type: string) => {
    switch (type) {
      case 'elementary': return '🏫';
      case 'middle': return '🏤';
      case 'high': return '🏛️';
      case 'university': return '🎓';
      default: return '🏫';
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', marginBottom: '24px', position: 'relative' }}>
        {/* Remove duplicate back button - parent dashboard handles navigation */}
        
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center', 
          gap: '8px', 
          marginBottom: '8px' 
        }}>
          <span style={{ fontSize: '32px' }}>🎓</span>
          <h2 style={{ 
            fontSize: '24px', 
            fontWeight: '700',
            background: 'linear-gradient(135deg, #7C3AED, #EC4899)',
            backgroundClip: 'text',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            margin: 0
          }}>
            EchoDeed™ for Schools
          </h2>
        </div>
        <p style={{ fontSize: '14px', color: '#6b7280', margin: 0 }}>
          Character Education through acts of kindness
        </p>
      </div>

      {/* Kindness Connect Info Card for Administrators */}
      <div style={{
        background: 'linear-gradient(135deg, #EC4899 0%, #EF4444 100%)',
        borderRadius: '16px',
        padding: '20px',
        marginBottom: '24px',
        boxShadow: '0 4px 12px rgba(236, 72, 153, 0.25)',
        border: '2px solid rgba(255, 255, 255, 0.3)'
      }}>
        <div style={{ display: 'flex', alignItems: 'start', gap: '16px' }}>
          <div style={{ 
            width: '48px', 
            height: '48px', 
            background: 'white',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '24px',
            flexShrink: 0,
            animation: 'pulse 2s infinite'
          }}>
            💝
          </div>
          <div style={{ flex: 1 }}>
            <h3 style={{ fontSize: '18px', fontWeight: '700', color: 'white', margin: 0, marginBottom: '8px' }}>
              Kindness Connect - Community Service Platform
            </h3>
            <p style={{ fontSize: '14px', color: 'rgba(255, 255, 255, 0.95)', margin: 0, marginBottom: '12px', lineHeight: '1.5' }}>
              Our Kindness Connect platform streamlines community service coordination for your school. Students discover 10+ pre-vetted local organizations, track service hours with photo verification, and earn tokens automatically. Teachers approve hours in one click, reducing administrative burden by 75%.
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '12px' }}>
              <span style={{ 
                padding: '6px 12px', 
                background: 'rgba(255, 255, 255, 0.9)', 
                borderRadius: '12px', 
                fontSize: '11px', 
                fontWeight: '600',
                color: '#EC4899'
              }}>
                📸 Photo Verification
              </span>
              <span style={{ 
                padding: '6px 12px', 
                background: 'rgba(255, 255, 255, 0.9)', 
                borderRadius: '12px', 
                fontSize: '11px', 
                fontWeight: '600',
                color: '#EC4899'
              }}>
                ✅ One-Click Approval
              </span>
              <span style={{ 
                padding: '6px 12px', 
                background: 'rgba(255, 255, 255, 0.9)', 
                borderRadius: '12px', 
                fontSize: '11px', 
                fontWeight: '600',
                color: '#EC4899'
              }}>
                📊 Auto-Tracked Hours
              </span>
              <span style={{ 
                padding: '6px 12px', 
                background: 'rgba(255, 255, 255, 0.9)', 
                borderRadius: '12px', 
                fontSize: '11px', 
                fontWeight: '600',
                color: '#EC4899'
              }}>
                👪 Parent Notifications
              </span>
            </div>
            <p style={{ fontSize: '12px', color: 'rgba(255, 255, 255, 0.9)', margin: 0, fontStyle: 'italic' }}>
              💡 Schools report 80% reduction in service hour verification paperwork and increased student engagement in community service programs.
            </p>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))',
        background: '#f3f4f6',
        borderRadius: '8px',
        padding: '4px',
        gap: '4px',
        marginBottom: '24px'
      }}>
        {[
          { id: 'overview', label: '📊 Overview' },
          { id: 'student', label: '👨‍🎓 Student' },
          { id: 'teacher', label: '👩‍🏫 Teacher' },
          { id: 'admin', label: '👩‍💼 Admin' },
          { id: 'parent', label: '👨‍👩‍👧‍👦 Parents' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              if (tab.id === 'parent') {
                navigate('/parent');
              } else if (tab.id === 'admin') {
                navigate('/admin');
              } else {
                setActiveTab(tab.id as any);
              }
            }}
            style={{
              padding: '8px 12px',
              borderRadius: '4px',
              border: 'none',
              fontSize: '11px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              background: activeTab === tab.id ? '#7C3AED' : 'transparent',
              color: activeTab === tab.id ? 'white' : '#6b7280',
              whiteSpace: 'nowrap',
              textAlign: 'center'
            }}
            data-testid={`school-tab-${tab.id}`}
          >
            {tab.label}
          </button>
        ))}
      </div>


      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Schools Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
            {sampleSchools.map((school) => (
              <div
                key={school.id}
                style={{
                  background: 'white',
                  borderRadius: '12px',
                  padding: '16px',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                  border: '1px solid #e5e7eb'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
                  <span style={{ fontSize: '24px' }}>{getSchoolIcon(school.type)}</span>
                  <div>
                    <h3 style={{ fontSize: '14px', fontWeight: '600', margin: 0, color: '#111827' }}>
                      {school.name}
                    </h3>
                    <p style={{ fontSize: '12px', color: '#6b7280', margin: 0, textTransform: 'capitalize' }}>
                      {school.type} • {school.studentCount} students
                    </p>
                  </div>
                </div>
                
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '12px' }}>
                  <div style={{ textAlign: 'center', padding: '8px', background: '#f0f9ff', borderRadius: '6px' }}>
                    <div style={{ fontWeight: '700', color: '#1e40af' }}>{school.totalKindnessActs}</div>
                    <div style={{ color: '#6b7280' }}>Kind Acts</div>
                  </div>
                  <div style={{ textAlign: 'center', padding: '8px', background: '#f0fdf4', borderRadius: '6px' }}>
                    <div style={{ fontWeight: '700', color: '#166534' }}>{school.avgKindnessScore}/10</div>
                    <div style={{ color: '#6b7280' }}>Avg Score</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Stats */}
          <div style={{
            background: 'linear-gradient(135deg, rgba(124,58,237,0.1) 0%, rgba(236,72,153,0.1) 100%)',
            border: '1px solid rgba(124,58,237,0.2)',
            borderRadius: '12px',
            padding: '20px'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '16px', fontWeight: '600', margin: 0, color: '#7C3AED' }}>
                📊 Lincoln Unified School District
              </h3>
              <button
                onClick={() => navigate('/admin')}
                style={{
                  background: '#7C3AED',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  padding: '6px 12px',
                  fontSize: '12px',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}
                data-testid="district-admin-access"
              >
                👩‍💼 District Admin
              </button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px' }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '24px', fontWeight: '700', color: '#7C3AED' }}>
                  {sampleSchools.reduce((sum, school) => sum + school.studentCount, 0).toLocaleString()}
                </div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Total Students</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '24px', fontWeight: '700', color: '#EC4899' }}>
                  {sampleSchools.reduce((sum, school) => sum + school.totalKindnessActs, 0).toLocaleString()}
                </div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Kindness Acts</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '24px', fontWeight: '700', color: '#10B981' }}>
                  {sampleSchools.length}
                </div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Schools</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'student' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* Student Profile Card */}
          <div style={{
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            borderRadius: '12px',
            padding: '20px',
            color: 'white',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '48px', marginBottom: '8px' }}>👨‍🎓</div>
            <h3 style={{ fontSize: '18px', fontWeight: '600', margin: 0, marginBottom: '4px' }}>
              Emma Johnson
            </h3>
            <p style={{ fontSize: '14px', opacity: 0.9, margin: 0 }}>
              6th Grade • Riverside Middle School
            </p>
          </div>

          {/* My Kindness Stats */}
          <div style={{
            background: 'white',
            borderRadius: '12px',
            padding: '16px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px', color: '#7C3AED' }}>
              📊 My Kindness Journey
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div style={{ textAlign: 'center', padding: '16px', background: '#f0f9ff', borderRadius: '8px' }}>
                <div style={{ fontSize: '24px', fontWeight: '700', color: '#1e40af' }}>245</div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Total Kindness Points</div>
              </div>
              <div style={{ textAlign: 'center', padding: '16px', background: '#f0fdf4', borderRadius: '8px' }}>
                <div style={{ fontSize: '24px', fontWeight: '700', color: '#166534' }}>15</div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>This Week</div>
              </div>
            </div>
          </div>

          {/* My Recent Acts */}
          <div style={{
            background: 'white',
            borderRadius: '12px',
            padding: '16px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px' }}>
              🌟 My Recent Kind Acts
            </h3>
            {[
              { act: 'Helped classmate with math homework', points: 5, date: 'Today' },
              { act: 'Shared lunch with new student', points: 8, date: 'Yesterday' },
              { act: 'Cleaned up classroom without being asked', points: 6, date: '2 days ago' }
            ].map((item, index) => (
              <div
                key={index}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '12px',
                  borderRadius: '8px',
                  background: '#f9fafb',
                  border: '1px solid #e5e7eb',
                  marginBottom: '8px'
                }}
              >
                <div>
                  <div style={{ fontSize: '14px', fontWeight: '500' }}>{item.act}</div>
                  <div style={{ fontSize: '12px', color: '#6b7280' }}>{item.date}</div>
                </div>
                <div style={{
                  background: '#7C3AED',
                  color: 'white',
                  padding: '4px 8px',
                  borderRadius: '6px',
                  fontSize: '12px',
                  fontWeight: '600'
                }}>
                  +{item.points}
                </div>
              </div>
            ))}
          </div>

          {/* New Kind Act Button */}
          <button style={{
            background: 'linear-gradient(135deg, #7C3AED, #EC4899)',
            color: 'white',
            border: 'none',
            borderRadius: '12px',
            padding: '16px',
            fontSize: '16px',
            fontWeight: '600',
            cursor: 'pointer',
            textAlign: 'center'
          }}>
            ✨ Record New Kind Act
          </button>
        </div>
      )}

      {activeTab === 'teacher' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* Teacher Profile */}
          <div style={{
            background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            borderRadius: '12px',
            padding: '20px',
            color: 'white',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '48px', marginBottom: '8px' }}>👩‍🏫</div>
            <h3 style={{ fontSize: '18px', fontWeight: '600', margin: 0, marginBottom: '4px' }}>
              Mrs. Sarah Davis
            </h3>
            <p style={{ fontSize: '14px', opacity: 0.9, margin: 0 }}>
              5th Grade Teacher • Room 12A
            </p>
          </div>

          {/* Class Statistics */}
          <div style={{
            background: 'white',
            borderRadius: '12px',
            padding: '16px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px', color: '#10b981' }}>
              📚 My Class Overview
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px' }}>
              <div style={{ textAlign: 'center', padding: '16px', background: '#f0fdf4', borderRadius: '8px' }}>
                <div style={{ fontSize: '20px', fontWeight: '700', color: '#166534' }}>28</div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Students</div>
              </div>
              <div style={{ textAlign: 'center', padding: '16px', background: '#fef3c7', borderRadius: '8px' }}>
                <div style={{ fontSize: '20px', fontWeight: '700', color: '#92400e' }}>156</div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Class Points</div>
              </div>
              <div style={{ textAlign: 'center', padding: '16px', background: '#f0f9ff', borderRadius: '8px' }}>
                <div style={{ fontSize: '20px', fontWeight: '700', color: '#1e40af' }}>8.2</div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Avg Score</div>
              </div>
            </div>
          </div>

          {/* Active Assignments */}
          <div style={{
            background: 'white',
            borderRadius: '12px',
            padding: '16px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px' }}>
              📋 Active Kindness Assignments
            </h3>
            {[
              { title: 'Lunch Buddy Challenge', due: 'Dec 15', completed: 18, total: 28 },
              { title: 'Compliment Chain', due: 'Dec 20', completed: 24, total: 28 },
              { title: 'Helper of the Week', due: 'Dec 22', completed: 28, total: 28 }
            ].map((assignment, index) => (
              <div
                key={index}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '12px',
                  borderRadius: '8px',
                  background: '#f9fafb',
                  border: '1px solid #e5e7eb',
                  marginBottom: '8px'
                }}
              >
                <div>
                  <div style={{ fontSize: '14px', fontWeight: '600' }}>{assignment.title}</div>
                  <div style={{ fontSize: '12px', color: '#6b7280' }}>Due: {assignment.due}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '14px', fontWeight: '600', color: '#10b981' }}>
                    {assignment.completed}/{assignment.total}
                  </div>
                  <div style={{ fontSize: '12px', color: '#6b7280' }}>completed</div>
                </div>
              </div>
            ))}
            
            <button style={{
              background: '#10b981',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              padding: '12px 20px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer',
              width: '100%',
              marginTop: '12px'
            }}>
              + Create New Assignment
            </button>
          </div>
        </div>
      )}

      {activeTab === 'admin' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* Admin Profile */}
          <div style={{
            background: 'linear-gradient(135deg, #dc2626 0%, #991b1b 100%)',
            borderRadius: '12px',
            padding: '20px',
            color: 'white',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '48px', marginBottom: '8px' }}>👩‍💼</div>
            <h3 style={{ fontSize: '18px', fontWeight: '600', margin: 0, marginBottom: '4px' }}>
              Principal Johnson
            </h3>
            <p style={{ fontSize: '14px', opacity: 0.9, margin: 0 }}>
              School Administrator • Riverside Elementary
            </p>
          </div>

          {/* School-Wide Statistics */}
          <div style={{
            background: 'white',
            borderRadius: '12px',
            padding: '16px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px', color: '#dc2626' }}>
              🏫 School-Wide Impact
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div style={{ textAlign: 'center', padding: '16px', background: '#fef2f2', borderRadius: '8px' }}>
                <div style={{ fontSize: '24px', fontWeight: '700', color: '#dc2626' }}>345</div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Total Students</div>
              </div>
              <div style={{ textAlign: 'center', padding: '16px', background: '#f0fdf4', borderRadius: '8px' }}>
                <div style={{ fontSize: '24px', fontWeight: '700', color: '#166534' }}>1247</div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Kind Acts This Month</div>
              </div>
              <div style={{ textAlign: 'center', padding: '16px', background: '#f0f9ff', borderRadius: '8px' }}>
                <div style={{ fontSize: '24px', fontWeight: '700', color: '#1e40af' }}>28</div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>Active Teachers</div>
              </div>
              <div style={{ textAlign: 'center', padding: '16px', background: '#fef3c7', borderRadius: '8px' }}>
                <div style={{ fontSize: '24px', fontWeight: '700', color: '#92400e' }}>8.4</div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>School Kindness Score</div>
              </div>
            </div>
          </div>

          {/* 🎓 TEACHER UPLIFT PULSE: Teacher Appreciation Metrics */}
          <TeacherAppreciationMetrics schoolId="bc016cad-fa89-44fb-aab0-76f82c574f78" />

          {/* Recent Highlights */}
          <div style={{
            background: 'white',
            borderRadius: '12px',
            padding: '16px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px' }}>
              ⭐ Recent Highlights
            </h3>
            {[
              { event: 'School-wide Kindness Week completed', impact: '98% participation', date: 'Dec 10' },
              { event: 'Anti-bullying program launch', impact: '100% teacher training', date: 'Dec 8' },
              { event: 'Parent-Teacher kindness conference', impact: '85% attendance', date: 'Dec 5' }
            ].map((item, index) => (
              <div
                key={index}
                style={{
                  padding: '12px',
                  borderRadius: '8px',
                  background: '#f9fafb',
                  border: '1px solid #e5e7eb',
                  marginBottom: '8px'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontSize: '14px', fontWeight: '600' }}>{item.event}</div>
                    <div style={{ fontSize: '12px', color: '#10b981', fontWeight: '500' }}>{item.impact}</div>
                  </div>
                  <div style={{ fontSize: '12px', color: '#6b7280' }}>{item.date}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Admin Actions */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '12px'
          }}>
            <button style={{
              background: '#dc2626',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              padding: '12px 16px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer'
            }}>
              📊 Generate Report
            </button>
            <button style={{
              background: '#7C3AED',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              padding: '12px 16px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer'
            }}>
              ⚙️ Manage Settings
            </button>
          </div>
        </div>
      )}
      
      {/* Left Sidebar */}
      {onNavigateToTab && (
        <LeftSidebar 
          activeTab={activeBottomTab} 
          onTabChange={onNavigateToTab}
        />
      )}
      
      {/* Kindness Connect FAB */}
      <div
        onClick={() => setIsKindnessConnectOpen(true)}
        data-testid="button-kindness-connect-fab"
        style={{
          position: 'fixed',
          bottom: '24px',
          right: '24px',
          cursor: 'pointer',
          zIndex: 9999,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '6px'
        }}
      >
        <button
          style={{
            width: '64px',
            height: '64px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #ec4899 0%, #ef4444 100%)',
            border: '3px solid white',
            boxShadow: '0 8px 25px rgba(239, 68, 68, 0.4), 0 0 0 0 rgba(239, 68, 68, 0.7)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'transform 0.2s ease, box-shadow 0.2s ease',
            animation: 'pulse-kindness 2s infinite'
          }}
        >
          <span style={{ fontSize: '32px' }}>💝</span>
        </button>
        <div
          style={{
            background: 'linear-gradient(135deg, #ec4899 0%, #ef4444 100%)',
            color: 'white',
            padding: '6px 12px',
            borderRadius: '12px',
            fontSize: '12px',
            fontWeight: '700',
            boxShadow: '0 4px 12px rgba(239, 68, 68, 0.3)',
            whiteSpace: 'nowrap',
            border: '2px solid white'
          }}
        >
          Kindness Connect
        </div>
      </div>
      
      <style>{`
        @keyframes pulse-kindness {
          0%, 100% {
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.4), 0 0 0 0 rgba(239, 68, 68, 0.7);
          }
          50% {
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.4), 0 0 0 10px rgba(239, 68, 68, 0);
          }
        }
      `}</style>
      
      <KindnessConnectModal 
        isOpen={isKindnessConnectOpen}
        onClose={() => setIsKindnessConnectOpen(false)}
      />
    </div>
  );
}