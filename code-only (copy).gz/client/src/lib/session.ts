// Anonymous session management for $ECHO tokens
// No personal data stored, just a random session ID

const SCHOOL_LEVEL_KEY = 'demo_school_level_override';

// Set default school level to high_school ONLY if not already set (preserves user's toggle choice)
if (typeof window !== 'undefined' && !localStorage.getItem(SCHOOL_LEVEL_KEY)) {
  localStorage.setItem(SCHOOL_LEVEL_KEY, 'high_school');
}

export function getSessionId(): string {
  const SESSION_KEY = 'echodeed_session';
  
  // Check if session exists in localStorage
  let sessionId = localStorage.getItem(SESSION_KEY);
  
  if (!sessionId) {
    // Generate new anonymous session ID
    sessionId = 'anon_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now().toString(36);
    localStorage.setItem(SESSION_KEY, sessionId);
  }
  
  return sessionId;
}

export function clearSession(): void {
  const SESSION_KEY = 'echodeed_session';
  localStorage.removeItem(SESSION_KEY);
}

// Add session ID to fetch headers
export function addSessionHeaders(headers: HeadersInit = {}): HeadersInit {
  // PRODUCTION DEMO MODE FIX: Always use demo session when DEMO_MODE is enabled
  // This ensures production demos (www.echodeed.com) work without real authentication
  const isDemoMode = import.meta.env.VITE_DEMO_MODE === 'true' || 
                     window.location.hostname === 'www.echodeed.com' ||
                     window.location.hostname.includes('echodeed.com');
  
  const userRole = localStorage.getItem('echodeed_demo_role') || 'student';
  // Use stored session ID from localStorage (set by switchDemoRole) or generate one
  const storedSession = localStorage.getItem('echodeed_session');
  const sessionId = storedSession || (isDemoMode ? 'demo-session' : getSessionId());
  
  // Get school level from localStorage (force high_school for consistent demo)
  const schoolLevel = localStorage.getItem('demo_school_level_override') || 'high_school';
  
  return {
    ...headers,
    'X-Session-ID': sessionId,
    'X-Demo-Role': userRole, // Send user's actual role to server
    'X-School-Level': schoolLevel, // Ensure high_school level is locked in
  };
}