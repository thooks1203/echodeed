import { SponsorDashboard } from '@/components/SponsorDashboard';

export default function SponsorDemo() {
  return (
    <div>
      <SponsorDashboard sponsorCompany="TechFlow Inc" />
    </div>
  );
}